<?
$MESS["SALE_EMPTY_BASKET"] = "Your shopping cart is empty";
$MESS["SBB_PRODUCT_NOT_AVAILABLE"] = "#PRODUCT# is out of stock";
$MESS["SBB_PRODUCT_NOT_ENOUGH_QUANTITY"] = "The current stock of \"#PRODUCT#\" is insufficient (#NUMBER# is required)";
$MESS["SOA_TEMPL_ORDER_PS_ERROR"] = "The selected payment method failed. Please contact the site administrator or select another method.";
?>