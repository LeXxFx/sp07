<?
$MESS["SALE_MODULE_NOT_INSTALL"] = "e-Store module is not installed";
$MESS["SALE_EMPTY_BASKET"] = "Your shopping cart is empty";
$MESS["SBB_TITLE"] = "My shopping cart";
$MESS["SBB_PRODUCT_NOT_AVAILABLE"] = "#PRODUCT# is out of stock";
$MESS["SBB_PRODUCT_NOT_ENOUGH_QUANTITY"] = "The current stock of \"#PRODUCT#\" is insufficient (#NUMBER# is required)";
$MESS["SBB_PRODUCT_PRICE_NOT_FOUND"] = "Product price was not found.";
?>