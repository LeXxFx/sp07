<?
$MESS["PATH_TO_ORDER_TIP"] = "The path name of the order completion page. You can specify only the file name if the page is in the current directory.";
$MESS["HIDE_COUPON_TIP"] = "Select \"Yes\" to hide the coupon code input field in the basket page.";
$MESS["COLUMNS_LIST_TIP"] = "Selected fields will be used as columns titles in a basket contents table.";
$MESS["SET_TITLE_TIP"] = "Checking this option will set the page title to \"My Shopping Cart\".";
$MESS["PRICE_VAT_INCLUDE_TIP"] = "Checking this option specifies to include tax in the display prices.";
$MESS["PRICE_VAT_SHOW_VALUE_TIP"] = "Specifies to show the tax value.";
?>