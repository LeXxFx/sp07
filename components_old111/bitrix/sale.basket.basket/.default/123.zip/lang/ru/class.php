<?
$MESS["SALE_EMPTY_BASKET"] = "Ваша корзина пуста";
$MESS["SBB_PRODUCT_NOT_AVAILABLE"] = "Товар #PRODUCT# не доступен для заказа";
$MESS["SBB_PRODUCT_NOT_ENOUGH_QUANTITY"] = "Для оформления заказа недостаточно товара \"#PRODUCT#\" в количество #NUMBER#";
$MESS["SOA_TEMPL_ORDER_PS_ERROR"] = "Ошибка выбранного способа оплаты. Обратитесь к Администрации сайта, либо выберите другой способ оплаты.";
?>