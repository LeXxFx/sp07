<?
$MESS ['SBB_DEFAULT_TEMPLATE_NAME'] = "Корзина";
$MESS ['SBB_DEFAULT_TEMPLATE_DESCRIPTION'] = "Выводит корзину текущего пользователя";
$MESS ['SBB_NAME'] = "Корзина";
?>