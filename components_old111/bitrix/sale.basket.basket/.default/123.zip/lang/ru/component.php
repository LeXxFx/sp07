<?
$MESS["SALE_MODULE_NOT_INSTALL"] = "Модуль Интернет-магазин не установлен.";
$MESS["SALE_EMPTY_BASKET"] = "Ваша корзина пуста";
$MESS["SBB_TITLE"] = "Моя корзина";
$MESS["SBB_PRODUCT_NOT_AVAILABLE"] = "Товар #PRODUCT# не доступен для заказа";
$MESS["SBB_PRODUCT_NOT_ENOUGH_QUANTITY"] = "Для оформления заказа недостаточно товара \"#PRODUCT#\" в количество #NUMBER#";
$MESS["SBB_PRODUCT_PRICE_NOT_FOUND"] = "Не найдена цена продукта";
?>