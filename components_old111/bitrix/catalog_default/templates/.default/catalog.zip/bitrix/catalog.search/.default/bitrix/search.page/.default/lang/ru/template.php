<?
$MESS["SEARCH_GO"] = "Искать";
$MESS["CT_BSP_ADDITIONAL_PARAMS"] = "Дополнительные параметры поиска";
$MESS["CT_BSP_KEYBOARD_WARNING"] = "В запросе \"#query#\" восстановлена раскладка клавиатуры.";
?>